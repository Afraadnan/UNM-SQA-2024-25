import logging
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from time import sleep
import time

# Function to configure logging
def setup_logging():
    log_filename = 'selenium_scroll_keyword_execution.log'
    logging.basicConfig(filename=log_filename, 
                        level=logging.INFO, 
                        format='%(asctime)s - %(levelname)s - %(message)s')
    logging.info('Test for Requirement5 started.')

# Set up logging
setup_logging()

logging.info('Starting WebDriver.')

try:
    # Initialize WebDriver
    wd = webdriver.Chrome(service=Service(r'D:/Nottingham Year3/Autumn/COMP3033 Software Quality Assurance/Coursework/2/Code/chromedriver.exe'))
    logging.info('WebDriver initialized.')

    # Set implicit wait
    wd.implicitly_wait(10)

    # Navigate to the webpage
    wd.get('file:///D:/Nottingham%20Year3/Autumn/COMP3033%20Software%20Quality%20Assurance/Coursework/2/Website/UNM-SQA-2024-25-main/UNM-SQA-2024-25-main/clone%202/index.html')
    logging.info('Navigated to SQATube webpage.')

    sleep(5)

    # Scrolling down
    logging.info('Starting scroll down actions.')
    for _ in range(50): 
        wd.execute_script(f"window.scrollBy(0, {100});")
        time.sleep(0.1)

    # Scrolling up
    logging.info('Starting scroll up actions.')
    for _ in range(50): 
        wd.execute_script(f"window.scrollBy(0, {-100});")
        time.sleep(0.1)

    # Click on first keyword button (kw1)
    kw1 = wd.find_element(By.CSS_SELECTOR, 'button.keyword-btn:nth-child(1)')
    logging.info('Clicking on the first keyword button.')
    kw1.click()
    sleep(2)

    # Scrolling down after click
    logging.info('Scrolling down after clicking the first keyword button.')
    for _ in range(50): 
        wd.execute_script(f"window.scrollBy(0, {100});")
        time.sleep(0.1)

    # Scrolling up after click
    logging.info('Scrolling up after clicking the first keyword button.')
    for _ in range(50): 
        wd.execute_script(f"window.scrollBy(0, {-100});")
        time.sleep(0.1)

    # Click on fourth keyword button (kw4)
    kw4 = wd.find_element(By.CSS_SELECTOR, 'button.keyword-btn:nth-child(4)')
    logging.info('Clicking on the fourth keyword button.')
    kw4.click()
    sleep(2)

    # Scrolling down after click
    logging.info('Scrolling down after clicking the fourth keyword button.')
    for _ in range(50): 
        wd.execute_script(f"window.scrollBy(0, {100});")
        time.sleep(0.1)

    # Scrolling up after click
    logging.info('Scrolling up after clicking the fourth keyword button.')
    for _ in range(50): 
        wd.execute_script(f"window.scrollBy(0, {-100});")
        time.sleep(0.1)

    sleep(2)

except Exception as e:
    logging.error(f'An error occurred: {e}')

finally:
    # Quit WebDriver
    wd.quit()
    logging.info('WebDriver closed, test completed.')
