import logging
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from time import sleep
import time
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains

# Function to configure logging
def setup_logging():
    log_filename = 'selenium_video_interaction_execution.log'
    logging.basicConfig(filename=log_filename, 
                        level=logging.INFO, 
                        format='%(asctime)s - %(levelname)s - %(message)s')
    logging.info('Test for Requirement4 started.')

# Set up logging
setup_logging()

logging.info('Starting WebDriver.')

try:
    # Initialize WebDriver
    wd = webdriver.Chrome(service=Service(r'D:/Nottingham Year3/Autumn/COMP3033 Software Quality Assurance/Coursework/2/Code/chromedriver.exe'))
    logging.info('WebDriver initialized.')

    # Set implicit wait
    wd.implicitly_wait(10)

    # Navigate to the webpage
    wd.get('file:///D:/Nottingham%20Year3/Autumn/COMP3033%20Software%20Quality%20Assurance/Coursework/2/Website/UNM-SQA-2024-25-main/UNM-SQA-2024-25-main/clone%202/index.html')
    logging.info('Navigated to SQATube webpage.')

    # Switch to the iframe containing the video
    video = wd.find_element(By.CSS_SELECTOR, 'div.video:nth-child(1)>iframe')
    logging.info('Found iframe containing video.')

    wd.switch_to.frame(video)
    logging.info('Switched to iframe.')

    # Find the video player and click play
    fstvideo = wd.find_element(By.CSS_SELECTOR, '#movie_player')
    logging.info('Found the video player element.')

    fstvideo.click()
    logging.info('Clicked on the video player to start playback.')

    sleep(7)

    # Fullscreen button click
    fs = wd.find_element(By.CSS_SELECTOR, 'button.ytp-fullscreen-button')
    logging.info('Found fullscreen button.')

    fs.click()
    logging.info('Clicked fullscreen button.')

    sleep(5)

    # Play/Pause the video
    play = wd.find_element(By.CSS_SELECTOR, '.ytp-play-button.ytp-button')
    logging.info('Found play button.')

    play.click()
    logging.info('Clicked play button to pause the video.')

    sleep(5)

    play.click()
    logging.info('Clicked play button again to play the video.')

    sleep(5)

    # Send arrow keys to seek forward and backward
    fstvideo.send_keys(Keys.ARROW_RIGHT)
    logging.info('Pressed right arrow key to seek forward.')

    sleep(5)

    fstvideo.send_keys(Keys.ARROW_LEFT)
    logging.info('Pressed left arrow key to seek backward.')

    sleep(7)

except Exception as e:
    logging.error(f'An error occurred: {e}')

finally:
    # Quit WebDriver
    wd.quit()
    logging.info('WebDriver closed, test completed.')
