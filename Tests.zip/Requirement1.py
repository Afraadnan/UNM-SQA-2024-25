import logging
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from time import sleep
import time
from selenium.webdriver.common.action_chains import ActionChains

# Function to configure logging
def setup_logging():
    log_filename = 'selenium_test_execution.log'
    logging.basicConfig(filename=log_filename, 
                        level=logging.INFO, 
                        format='%(asctime)s - %(levelname)s - %(message)s')
    logging.info('Test for Requirement1 started.')

# Set up logging
setup_logging()

logging.info('Starting WebDriver.')

try:
    # Initialize WebDriver
    wd = webdriver.Chrome(service=Service(r'D:/Nottingham Year3/Autumn/COMP3033 Software Quality Assurance/Coursework/2/Code/chromedriver.exe'))
    logging.info('WebDriver initialized.')

    # Set implicit wait
    wd.implicitly_wait(10)

    # Navigate to the page
    wd.get('file:///D:/Nottingham%20Year3/Autumn/COMP3033%20Software%20Quality%20Assurance/Coursework/2/Website/UNM-SQA-2024-25-main/UNM-SQA-2024-25-main/clone%202/index.html')
    logging.info('Navigated to SQATube webpage.')

    # Click on the button
    tag1 = wd.find_element(By.CSS_SELECTOR, 'button[data-keyword="AI DevOps Tools"]')
    logging.info('Found button with keyword "AI DevOps Tools".')

    sleep(5)
    tag1.click()
    logging.info('Clicked on the button.')

    sleep(5)

    # Scroll down
    logging.info('Starting scroll action.')
    for _ in range(50): 
        wd.execute_script(f"window.scrollBy(0, {50});")
        time.sleep(0.1)
        logging.info(f'Scrolled by 50px.')

    # Open YouTube in a new tab
    wd.execute_script("window.open('https://www.youtube.com/', '_blank');")
    logging.info('Opened YouTube in a new tab.')

    # Switch to YouTube tab
    for handle in wd.window_handles:
        wd.switch_to.window(handle)
        if 'YouTube' in wd.title:
            break
    logging.info('Switched to YouTube tab.')

    # Perform search on YouTube
    input_field = wd.find_element(By.CSS_SELECTOR, 'input#search')
    logging.info('Found search input field on YouTube.')
    input_field.send_keys('AI DevOps Tools')

    sleep(5)

    search_button = wd.find_element(By.CSS_SELECTOR, 'button#search-icon-legacy')
    logging.info('Found search button on YouTube.')
    search_button.click()

    sleep(5)

    # Scroll down YouTube search results
    logging.info('Starting scrolling on YouTube.')
    for _ in range(50): 
        wd.execute_script(f"window.scrollBy(0, {100});")
        time.sleep(0.1)

    sleep(5)

    logging.info('Scrolled down YouTube search results.')

    # Print the title of the page
    logging.info(f"Current page title: {wd.title}")

except Exception as e:
    logging.error(f'An error occurred: {e}')

finally:
    # Quit WebDriver
    wd.quit()
    logging.info('WebDriver closed, test completed.')
