import logging
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from time import sleep
import time
from selenium.webdriver.common.action_chains import ActionChains

# Function to configure logging
def setup_logging():
    log_filename = 'selenium_execution.log'
    logging.basicConfig(filename=log_filename, 
                        level=logging.INFO, 
                        format='%(asctime)s - %(levelname)s - %(message)s')
    logging.info('Test for Requirement6 started.')

# Set up logging
setup_logging()

logging.info('Starting WebDriver.')

try:
    # Initialize WebDriver
    wd = webdriver.Chrome(service=Service(r'D:/Nottingham Year3/Autumn/COMP3033 Software Quality Assurance/Coursework/2/Code/chromedriver.exe'))
    logging.info('WebDriver initialized.')

    # Set implicit wait
    wd.implicitly_wait(10)

    # Navigate to the webpage
    wd.get('file:///D:/Nottingham%20Year3/Autumn/COMP3033%20Software%20Quality%20Assurance/Coursework/2/Website/UNM-SQA-2024-25-main/UNM-SQA-2024-25-main/clone%202/index.html')
    logging.info('Navigated to SQATube webpage.')
    sleep(5)

    # Scroll down 50 times by 100 pixels
    logging.info('Starting scroll down actions.')
    for _ in range(50): 
        wd.execute_script(f"window.scrollBy(0, {100});")
        time.sleep(0.1)

    # Scroll up 50 times by 100 pixels
    logging.info('Starting scroll up actions.')
    for _ in range(50): 
        wd.execute_script(f"window.scrollBy(0, {-100});")
        time.sleep(0.1)

    logging.info('Scrolling completed.')

    # Find the search input field and enter 'travel'
    logging.info('Entering search term: travel.')
    src = wd.find_element(By.CSS_SELECTOR, '#search-input')
    src.send_keys('travel')

    # Find and click the search button
    logging.info('Clicking search button.')
    btn = wd.find_element(By.CSS_SELECTOR, '#search-button')
    btn.click()
    sleep(5)

    logging.info('Search executed.')

    # Clean former keyword
    logging.info('Clean former keyword')
    src.clear()
    sleep(5)

    logging.info('Entering search term: AI.')
    # Search for keyword "AI"
    src.send_keys('AI')

    # Find and click the search button
    logging.info('Clicking search button.')
    btn.click()
    sleep(5)

    logging.info('Search executed.')

except Exception as e:
    logging.error(f'An error occurred: {e}')

finally:
    # Quit WebDriver
    wd.quit()
    logging.info('WebDriver closed, test completed.')
