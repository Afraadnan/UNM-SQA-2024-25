import logging
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from time import sleep
import time
from selenium.webdriver.common.action_chains import ActionChains

# Configure logging
logging.basicConfig(filename='selenium_test_execution.log', 
                    level=logging.INFO, 
                    format='%(asctime)s - %(levelname)s - %(message)s')

# Log test start
logging.info('Test For Requirement2 started.')

try:
    # Set up WebDriver
    wd = webdriver.Chrome(service=Service(r'D:/Nottingham Year3/Autumn/COMP3033 Software Quality Assurance/Coursework/2/Code/chromedriver.exe'))
    logging.info('WebDriver initialized.')

    wd.implicitly_wait(10)

    # Navigate to the page
    wd.get('file:///D:/Nottingham%20Year3/Autumn/COMP3033%20Software%20Quality%20Assurance/Coursework/2/Website/UNM-SQA-2024-25-main/UNM-SQA-2024-25-main/clone%202/index.html')
    logging.info('Navigated to the webpage.')

    sleep(5)

    # Perform scrolling action
    logging.info('Starting scrolling action.')
    for _ in range(50):
        wd.execute_script(f"window.scrollBy(0, {100});")
        time.sleep(0.1)
        logging.info(f'Scrolled by 100px.')
    
    logging.info('Scrolling completed.')

except Exception as e:
    logging.error(f'An error occurred: {e}')

finally:
    # Clean up
    wd.quit()
    logging.info('WebDriver closed, test completed.')
