import logging
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from time import sleep
import time
from selenium.webdriver.support.ui import Select

# Function to configure logging
def setup_logging():
    log_filename = 'selenium_sort_select_execution.log'
    logging.basicConfig(filename=log_filename, 
                        level=logging.INFO, 
                        format='%(asctime)s - %(levelname)s - %(message)s')
    logging.info('Test for Requirement8 started.')

# Set up logging
setup_logging()

logging.info('Starting WebDriver.')

try:
    # Initialize WebDriver
    wd = webdriver.Chrome(service=Service(r'D:/Nottingham Year3/Autumn/COMP3033 Software Quality Assurance/Coursework/2/Code/chromedriver.exe'))
    logging.info('WebDriver initialized.')

    # Set implicit wait
    wd.implicitly_wait(10)

    # Navigate to the webpage
    wd.get('file:///D:/Nottingham%20Year3/Autumn/COMP3033%20Software%20Quality%20Assurance/Coursework/2/Website/UNM-SQA-2024-25-main/UNM-SQA-2024-25-main/clone%202/index.html')
    logging.info('Navigated to SQATube webpage.')

    sleep(5)

    # Interact with the sorting dropdown
    select = Select(wd.find_element(By.ID, "sortOptions"))
    logging.info('Found sorting dropdown element.')

    select.select_by_value('date')
    logging.info('Selected "date" option from sorting dropdown.')

    sleep(3)

    # Scrolling actions
    logging.info('Starting scroll down actions for "date" option.')
    for _ in range(50): 
        wd.execute_script(f"window.scrollBy(0, {100});")
        time.sleep(0.1)

    for _ in range(50): 
        wd.execute_script(f"window.scrollBy(0, {-100});")
        time.sleep(0.1)
    
    logging.info('Scrolling completed for "date" option.')

    # Change sorting to "relevance"
    select.select_by_value('relevance')
    logging.info('Selected "relevance" option from sorting dropdown.')

    sleep(3)

    logging.info('Starting scroll down actions for "relevance" option.')
    for _ in range(50): 
        wd.execute_script(f"window.scrollBy(0, {100});")
        time.sleep(0.1)

    for _ in range(50): 
        wd.execute_script(f"window.scrollBy(0, {-100});")
        time.sleep(0.1)

    logging.info('Scrolling completed for "relevance" option.')

    # Change sorting to "rating"
    select.select_by_value('rating')
    logging.info('Selected "rating" option from sorting dropdown.')

    sleep(3)

    logging.info('Starting scroll down actions for "rating" option.')
    for _ in range(50): 
        wd.execute_script(f"window.scrollBy(0, {100});")
        time.sleep(0.1)

    for _ in range(50): 
        wd.execute_script(f"window.scrollBy(0, {-100});")
        time.sleep(0.1)

    logging.info('Scrolling completed for "rating" option.')

    # Change sorting to "duration"
    select.select_by_value('duration')
    logging.info('Selected "duration" option from sorting dropdown.')

    sleep(3)

    logging.info('Starting scroll down actions for "duration" option.')
    for _ in range(50): 
        wd.execute_script(f"window.scrollBy(0, {100});")
        time.sleep(0.1)

    for _ in range(50): 
        wd.execute_script(f"window.scrollBy(0, {-100});")
        time.sleep(0.1)

    logging.info('Scrolling completed for "duration" option.')

except Exception as e:
    logging.error(f'An error occurred: {e}')

finally:
    # Quit WebDriver
    wd.quit()
    logging.info('WebDriver closed, test completed.')
