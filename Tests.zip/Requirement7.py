import logging
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from time import sleep
import time

# Function to configure logging
def setup_logging():
    log_filename = 'selenium_keyword_scroll_execution.log'
    logging.basicConfig(filename=log_filename, 
                        level=logging.INFO, 
                        format='%(asctime)s - %(levelname)s - %(message)s')
    logging.info('Test for Requirement7 started.')

# Set up logging
setup_logging()

logging.info('Starting WebDriver.')

try:
    # Initialize WebDriver
    wd = webdriver.Chrome(service=Service(r'D:/Nottingham Year3/Autumn/COMP3033 Software Quality Assurance/Coursework/2/Code/chromedriver.exe'))
    logging.info('WebDriver initialized.')

    # Set implicit wait
    wd.implicitly_wait(10)

    # Navigate to the webpage
    wd.get('file:///D:/Nottingham%20Year3/Autumn/COMP3033%20Software%20Quality%20Assurance/Coursework/2/Website/UNM-SQA-2024-25-main/UNM-SQA-2024-25-main/clone%202/index.html')
    logging.info('Navigated to SQATube webpage.')

    sleep(3)

    # Find and interact with "new keyword" input field
    nk = wd.find_element(By.CSS_SELECTOR, '#newKeyword')
    logging.info('Found "newKeyword" input field.')
    nk.send_keys('Best AI coding Tools')
    logging.info('Entered "Best AI coding Tools" in the newKeyword input field.')

    sleep(5)

    # Click the "Add Keyword" button
    ak = wd.find_element(By.CSS_SELECTOR, '#addKeywordButton')
    logging.info('Found "Add Keyword" button.')
    ak.click()
    logging.info('Clicked the "Add Keyword" button.')

    sleep(3)

    # Click on the new keyword button (6th keyword)
    kw6 = wd.find_element(By.CSS_SELECTOR, 'button.keyword-btn:nth-child(6)')
    logging.info('Found and clicking the 6th keyword button.')
    kw6.click()

    sleep(5)

    # Scrolling down
    logging.info('Starting scroll down actions.')
    for _ in range(50): 
        wd.execute_script(f"window.scrollBy(0, {100});")
        time.sleep(0.1)

    # Scrolling up
    logging.info('Starting scroll up actions.')
    for _ in range(50): 
        wd.execute_script(f"window.scrollBy(0, {-100});")
        time.sleep(0.1)

    logging.info('Scrolling completed.')

except Exception as e:
    logging.error(f'An error occurred: {e}')

finally:
    # Quit WebDriver
    wd.quit()
    logging.info('WebDriver closed, test completed.')
